p5.play is a p5.js library for the creation of games and playthings.

You can find examples and more information at [p5play.molleindustria.org] (http://p5play.molleindustria.org)

p5.play provides a Sprite class to manage visual objects in 2D space and features such as animation support, basic collision detection and resolution, sprite grouping, helpers for mouse and keyboard interactions, and a virtual camera. 

p5.play extends p5.js, a javascript library (and a community) that aims to make coding accessible for artists, designers, educators, and beginners. If you are not familiar with p5.js, you should start [here] (http://p5js.org/tutorials/).
